from setuptools import setup, find_packages

setup(
    name = "servoControl",
    version = "1.0",    
    packages = find_packages(),    

    description = "servo control",
    long_description = "package for servo control and servo demo",
    author = "SiyuanLiu-LeslieLiu",
    author_email = "tul55007@temple.edu",

    license = "GPL",
    keywords = ("servo", "control"),
    platforms = "Independant",
    entry_points = {
        'console_scripts': [
            'servoControl = servoControl.testServo:main'
        ]
    }
)
