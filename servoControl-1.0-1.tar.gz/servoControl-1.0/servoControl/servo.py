import RPI.GPIO as GPIO


class Servo():
    def __init__(self, pin=12, freq=50):
        self.pin = pin
        self.freq = freq
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(self.pin, GPIO.OUT)
        self.p = GPIO.PWM(self.pin, self.freq)

    def setDuty(self, dc):
        self.p.ChangeDutyCycle(dc)
