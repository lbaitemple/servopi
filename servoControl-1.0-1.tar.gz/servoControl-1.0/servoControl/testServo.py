from servo import Servo
import time

a = Servo(freq=50, pin=12)
while (true):
    time.sleep(1)
    a.setDuty(dc=7.5)
    time.sleep(1)
    a.setDuty(dc=2.5)
    time.sleep(1)
    a.setDuty(dc=12.5)
